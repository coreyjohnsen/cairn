# Cairn

A quiet, mountain-themed desktop app for chatting with any AI model, putting it to work on your files, and making pictures. Runs on Windows and Linux, uses NVIDIA (CUDA) and AMD (ROCm or Vulkan) GPUs, and works with local models, local servers and cloud APIs side by side.

## What it does

**Chat with any model.** Add as many connections as you like and pick between them from the chat box:

- This computer: Cairn downloads and manages llama.cpp for your GPU and runs GGUF models directly.
- Any OpenAI-compatible server: Ollama, LM Studio, llama.cpp, KoboldCpp, vLLM, OpenRouter, OpenAI, Groq, Together and so on. "Look for running servers" finds local ones for you.
- Anthropic (native API).

**Agent tools.** With tools switched on, a model can read, search, create, edit, move and delete files inside a working folder you choose, run shell commands, fetch web pages, search the web, and generate images. Anything that changes files or runs commands asks first (Allow once, Allow for this chat, Always allow, Decline), and file edits show a diff before you approve. You can also add:

- Custom tools: small JavaScript functions with a JSON schema and a built-in test runner. They run in a sandboxed worker with a timeout.
- MCP servers: stdio, SSE or streamable HTTP. Their tools appear next to the built-in ones and obey the same permissions.

**Image generation.**

- In chat: type `/imagine a misty alpine lake at dawn`, press the picture button, or just ask in plain words. A tool-capable model can also call `generate_image` itself.
- Image Hub: a gallery of everything you have made, with search, favourites, a full-screen viewer, reuse-settings, image-to-image and a create panel (model, shape, steps, CFG, sampler, seed, batch of 1, 2, 4 or 8).
- Backends: the built-in engine (stable-diffusion.cpp, downloaded for your GPU), ComfyUI, AUTOMATIC1111 / Forge, and OpenAI-style image APIs. Supports SD 1.x/2.x, SDXL, Flux and SD3 weights, including GGUF.

**Design.** Four mountain palettes (Alpenglow dusk, Glacier light, Granite, Timberline) plus "match system", drawn ridgeline art, no clutter. Text size, reduced motion and backdrop toggles are in Settings.

## Quick start (developers)

You need Node 22 or newer.

```
npm install
npm run dev
```

The dev window opens with hot reload. To look at the interface in a normal browser with scripted demo data and no Electron or backend:

```
npm run dev:web
```

then open http://localhost:5173 (options: `?theme=glacier`, `?view=images`, `?platform=win32`, `?scenario=empty`).

Windows users: keep the project **outside OneDrive** (for example `C:\dev\cairn`). `node_modules` contains tens of thousands of small files and OneDrive syncing will make installs and builds slow and flaky.

## Building the executables

```
npm install
npm run dist:win      # on Windows: NSIS installer + portable .exe  ->  release/
npm run dist:linux    # on Linux:   AppImage, .deb, .tar.gz         ->  release/
```

Build each platform on its own platform. Windows installers cannot be produced on Linux without Wine, and the repository's GitHub Actions workflow (`.github/workflows/build.yml`) does both for you: push a tag such as `v1.0.0` and it publishes the installers to a GitHub release.

Output files:

| Platform | File |
|---|---|
| Windows installer | `Cairn-<version>-win-x64.exe` |
| Windows portable (keeps data beside the exe) | `Cairn-<version>-portable.exe` |
| Linux | `Cairn-<version>-linux-x86_64.AppImage`, `Cairn-<version>-linux-amd64.deb`, `.tar.gz` |

The AppImage runs without installation: `chmod +x Cairn-*.AppImage && ./Cairn-*.AppImage`. It starts with Chromium's SUID sandbox disabled, because AppImages cannot ship the helper; the `.deb` keeps the normal sandbox.

The installers are not code-signed, so Windows SmartScreen will warn on first run ("More info", then "Run anyway"). Signing needs a certificate; electron-builder picks one up from the usual `CSC_LINK` / `CSC_KEY_PASSWORD` variables.

`npm run icons` regenerates `build/icon.*` from the vector mark in `scripts/make-icons.mjs`.

## GPUs

Open Models, then Engines and GPU. Cairn detects your GPU and recommends a backend:

- **NVIDIA (GTX and RTX):** CUDA builds. The newest CUDA runtime your driver supports is chosen automatically, and the matching runtime libraries are downloaded alongside. GTX 10-series and older are kept on CUDA 12.
- **AMD on Windows:** Vulkan is recommended and works well on RDNA 2 cards such as the RX 6900 XT. A HIP/ROCm build is offered when the upstream project publishes one for your engine.
- **AMD on Linux:** ROCm if it is installed, otherwise Vulkan through Mesa RADV. For RDNA 2 cards that ROCm does not officially list, set `HSA_OVERRIDE_GFX_VERSION=10.3.0` (Models, Engines and GPU has an Environment variables box for each engine).
- **No supported GPU:** CPU builds.

Engines are downloaded at runtime from the llama.cpp and stable-diffusion.cpp GitHub releases rather than bundled, so the installer stays small and you can update an engine without reinstalling the app.

## Getting models

- **Chat:** Models, then Local models. Search Hugging Face from inside the app, pick a GGUF quantisation, and download. Check the file size against your video memory first; GPU layers can be lowered if a model does not fit. Or connect a server that already has models.
- **Images:** Models, then Image models. Starter packs cover SDXL Turbo, SD Turbo and FLUX.1 schnell; you can also search Civitai or paste any direct link.

Tokens for Hugging Face and Civitai go in Settings, then Storage. Some files need one: FLUX's VAE (`ae.safetensors`) is gated, so accept the licence on its Hugging Face page and add a token. If Hugging Face returns a 403 or rate limit on a big file, a token usually fixes it, and any download can be resumed.

## Where things live

| | Windows | Linux |
|---|---|---|
| App data | `%APPDATA%\Cairn` | `~/.config/Cairn` |
| Models and engines | `<app data>\models`, `<app data>\engines` (changeable in Settings, Storage) | same |

Chats, settings and the image library are plain JSON and PNG files. API keys and tokens are encrypted with the operating system's keychain (Windows DPAPI, Linux libsecret/kwallet) when it is available. On a Linux machine with no keyring they are stored as plain text in the settings file, so keep that file private there. The portable Windows build and the `CAIRN_DATA_DIR` environment variable keep everything in a folder you choose.

## Safety model

File tools are confined to the chat's working folder; paths that escape it (including through symlinks and `..`) are refused. Reads and searches run automatically, writes, deletes and commands ask, and "Always allow" is deliberately not offered for deletes and commands. Every permission can be changed per tool under Tools. The renderer runs with context isolation, no Node integration, the Chromium sandbox and a strict Content-Security-Policy; remote images in model output are blocked.

## Project layout

```
src/main        Electron main process: providers, agent loop, tools, engines, image backends, storage
src/preload     the typed bridge exposed as window.cairn
src/renderer    React interface (views, components, stores, hand-written CSS themes)
src/shared      types and IPC contracts shared by both sides
tests           Vitest suites for the main process (npm test)
scripts         icon generation
```

`npm run typecheck` checks both halves, `npm test` runs the suites.

## What has and has not been verified

Verified in development: type checking and 180 unit tests pass; the production build and a Linux AppImage and .deb build and launch; in the real Electron app, streaming chat, a tool call with an approval prompt and diff, the resulting file on disk, `/imagine`, and Image Hub generation against stand-in OpenAI-style and AUTOMATIC1111 servers.

Not exercised on real hardware or networks, so expect to report rough edges: downloading engines and models from GitHub and Hugging Face, running llama.cpp and stable-diffusion.cpp on an actual GPU (CUDA, ROCm, Vulkan), ComfyUI and Anthropic live calls, the Windows installer, and the starter-pack download URLs (they are plain links you can edit in `src/shared/defaults.ts`).
