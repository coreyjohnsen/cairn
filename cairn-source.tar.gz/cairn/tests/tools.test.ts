import fs from 'node:fs'
import os from 'node:os'
import path from 'node:path'
import http from 'node:http'
import type { AddressInfo } from 'node:net'
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { fitHistory, historyFor } from '../src/main/agent/context'
import { detectImageRequest } from '../src/main/agent/intent'
import { runCustomTool, customToolImpl, renderTemplate } from '../src/main/tools/custom'
import { fsTools, planEdit } from '../src/main/tools/fs'
import { resolvePath } from '../src/main/tools/sandbox'
import { resolveShell, shellTools, OutputCollector } from '../src/main/tools/shell'
import { isPrivateHost, parseDuckDuckGo } from '../src/main/tools/web'
import { makeDiff } from '../src/main/util/diff'
import { globToRegExp, matchGlob } from '../src/main/util/glob'
import { htmlToText } from '../src/main/util/html'
import { parseToolArgs } from '../src/main/util/json'
import type { ChatMessage, CustomToolConfig } from '../src/shared/types'
import { makeCtx } from './helpers/ctx'

let ws: string
beforeEach(() => {
  ws = fs.mkdtempSync(path.join(os.tmpdir(), 'cairn-ws-'))
})
afterEach(() => {
  fs.rmSync(ws, { recursive: true, force: true })
})

const tool = (name: string) => [...fsTools(), ...shellTools()].find((t) => t.name === name)!

describe('sandbox', () => {
  it('keeps paths inside the workspace', () => {
    expect(resolvePath(ws, 'a/b.txt', false).inside).toBe(true)
    expect(() => resolvePath(ws, '../escape.txt', false)).toThrow(/outside the workspace/)
    expect(() => resolvePath(ws, '/etc/passwd', false)).toThrow(/outside the workspace/)
    expect(resolvePath(ws, '/etc/passwd', true).inside).toBe(false)
  })
  it('blocks symlink escapes', () => {
    const outside = fs.mkdtempSync(path.join(os.tmpdir(), 'cairn-out-'))
    fs.symlinkSync(outside, path.join(ws, 'link'))
    expect(() => resolvePath(ws, 'link/secret.txt', false)).toThrow(/outside the workspace/)
    fs.rmSync(outside, { recursive: true, force: true })
  })
  it('requires a workspace for relative paths', () => {
    expect(() => resolvePath(null, 'a.txt', false)).toThrow(/No workspace/)
  })
})

describe('file tools', () => {
  it('write → read → edit → search → find → move → delete', async () => {
    const ctx = makeCtx(ws)
    await tool('write_file').execute({ path: 'src/app.ts', content: 'const a = 1\nconst b = 2\nconsole.log(a + b)\n' }, ctx)
    const read = await tool('read_file').execute({ path: 'src/app.ts' }, ctx)
    expect(read.content).toContain('     2\tconst b = 2')

    const edit = await tool('edit_file').execute({ path: 'src/app.ts', old_string: 'const b = 2', new_string: 'const b = 40' }, ctx)
    expect(edit.content).toMatch(/1 replacement/)
    expect(fs.readFileSync(path.join(ws, 'src/app.ts'), 'utf8')).toContain('const b = 40')

    const found = await tool('search_files').execute({ pattern: 'const \\w = \\d+', glob: '*.ts' }, ctx)
    expect(found.content).toContain('src/app.ts:1:')
    expect(found.content).toContain('src/app.ts:2:')

    const files = await tool('find_files').execute({ glob: '**/*.ts' }, ctx)
    expect(files.content.trim()).toBe('src/app.ts')

    await tool('move_path').execute({ from: 'src/app.ts', to: 'lib/app.ts' }, ctx)
    expect(fs.existsSync(path.join(ws, 'lib/app.ts'))).toBe(true)

    await expect(tool('delete_path').execute({ path: 'lib' }, ctx)).rejects.toThrow(/recursive/)
    await tool('delete_path').execute({ path: 'lib', recursive: true }, ctx)
    expect(fs.existsSync(path.join(ws, 'lib'))).toBe(false)
  })

  it('edit_file rejects ambiguous and missing matches, and handles CRLF', async () => {
    const ctx = makeCtx(ws)
    fs.writeFileSync(path.join(ws, 'x.txt'), 'foo\nfoo\n')
    await expect(planEdit({ path: 'x.txt', old_string: 'foo', new_string: 'bar' }, ctx)).rejects.toThrow(/2 times/)
    await expect(planEdit({ path: 'x.txt', old_string: 'nope', new_string: 'bar' }, ctx)).rejects.toThrow(/not found/)
    const plan = await planEdit({ path: 'x.txt', old_string: 'foo', new_string: 'bar', replace_all: true }, ctx)
    expect(plan.after).toBe('bar\nbar\n')
    fs.writeFileSync(path.join(ws, 'crlf.txt'), 'a\r\nb\r\nc\r\n')
    const crlf = await planEdit({ path: 'crlf.txt', old_string: 'a\nb', new_string: 'a\nB' }, ctx)
    expect(crlf.after).toBe('a\r\nB\r\nc\r\n')
  })

  it('refuses to read binary files and paths outside the workspace', async () => {
    const ctx = makeCtx(ws)
    fs.writeFileSync(path.join(ws, 'bin.dat'), Buffer.from([1, 2, 0, 3]))
    await expect(tool('read_file').execute({ path: 'bin.dat' }, ctx)).rejects.toThrow(/binary/)
    await expect(tool('read_file').execute({ path: '../../etc/hostname' }, ctx)).rejects.toThrow(/outside/)
  })

  it('forces approval for outside-workspace access when allowed', async () => {
    const ctx = makeCtx(ws, (s) => (s.agent.allowOutsideWorkspace = true))
    const p = await tool('write_file').describe!({ path: '/tmp/cairn-outside.txt', content: 'x' }, ctx)
    expect(p.forceApproval).toBe(true)
    const q = await tool('write_file').describe!({ path: 'inside.txt', content: 'x' }, ctx)
    expect(q.forceApproval).toBeFalsy()
    expect(q.diff).toContain('+x')
  })
})

describe('run_command', () => {
  it('captures output and exit code', async () => {
    const ctx = makeCtx(ws)
    const ok = await tool('run_command').execute({ command: 'echo hello && pwd' }, ctx)
    expect(ok.content).toContain('Exit code: 0')
    expect(ok.content).toContain('hello')
    expect(ok.content).toContain(fs.realpathSync(ws))
    const bad = await tool('run_command').execute({ command: 'echo oops >&2; exit 3' }, ctx)
    expect(bad.isError).toBe(true)
    expect(bad.content).toContain('Exit code: 3')
    expect(bad.content).toContain('oops')
  })
  it('kills long-running commands on timeout', async () => {
    const ctx = makeCtx(ws)
    const r = await tool('run_command').execute({ command: 'sleep 5', timeout_sec: 1 }, ctx)
    expect(r.content).toMatch(/timed out/)
  }, 10000)
  it('picks sensible shells per platform', () => {
    expect(resolveShell('auto', 'win32').name).toBe('PowerShell')
    expect(resolveShell('cmd', 'win32').file).toBe('cmd.exe')
  })
  it('OutputCollector keeps head and tail of huge output', () => {
    const c = new OutputCollector(10, 10)
    c.push('A'.repeat(50))
    c.push('B'.repeat(50))
    expect(c.toString()).toMatch(/^A{10}[\s\S]*omitted[\s\S]*B{10}$/)
  })
})

describe('custom tools', () => {
  const base = { id: '1', name: 'my_tool', description: 'd', enabled: true, parameters: '{"type":"object","properties":{"who":{"type":"string"}}}', permission: 'ask' as const }
  it('renders templates', () => {
    expect(renderTemplate('hi {{ who }} {{n}} {{missing}}!', { who: 'you', n: 3 })).toBe('hi you 3 !')
  })
  it('runs a command without a shell, passing args on stdin and as env', async () => {
    const cfg: CustomToolConfig = {
      ...base,
      impl: { type: 'command', file: process.execPath, args: ['-e', 'let s="";process.stdin.on("data",d=>s+=d).on("end",()=>console.log("stdin="+s+" env="+process.env.CAIRN_ARGS+" argv="+process.argv[1]))', '{{who}}'], timeoutSec: 10 }
    }
    const r = await runCustomTool(cfg, { who: 'world; rm -rf /' }, makeCtx(ws))
    expect(r.isError).toBeFalsy()
    expect(r.content).toContain('stdin={"who":"world; rm -rf /"}')
    expect(r.content).toContain('argv=world; rm -rf /')
  })
  it('runs JavaScript tools in a worker with timeout', async () => {
    const cfg: CustomToolConfig = { ...base, impl: { type: 'javascript', code: 'console.log("hi"); return { sum: args.a + args.b }', timeoutSec: 5 } }
    const r = await runCustomTool(cfg, { a: 2, b: 3 }, makeCtx(ws))
    expect(r.content).toContain('"sum": 5')
    expect(r.content).toContain('hi')
    const slow: CustomToolConfig = { ...base, impl: { type: 'javascript', code: 'while(true){}', timeoutSec: 1 } }
    expect((await runCustomTool(slow, {}, makeCtx(ws))).content).toMatch(/Timed out/)
    const bad: CustomToolConfig = { ...base, impl: { type: 'javascript', code: 'throw new Error("boom")', timeoutSec: 5 } }
    const e = await runCustomTool(bad, {}, makeCtx(ws))
    expect(e.isError).toBe(true)
    expect(e.content).toContain('boom')
  })
  it('calls HTTP tools', async () => {
    let seen = ''
    const srv = http.createServer((req, res) => {
      let b = ''
      req.on('data', (c) => (b += c))
      req.on('end', () => {
        seen = `${req.method} ${req.url} ${req.headers['x-token']} ${b}`
        res.end('pong')
      })
    })
    await new Promise<void>((r) => srv.listen(0, '127.0.0.1', r))
    const port = (srv.address() as AddressInfo).port
    const cfg: CustomToolConfig = { ...base, impl: { type: 'http', method: 'POST', url: `http://127.0.0.1:${port}/echo?q={{who}}`, headers: { 'X-Token': 'abc' }, body: '{"who":"{{who}}"}', timeoutSec: 5 } }
    const r = await runCustomTool(cfg, { who: 'me' }, makeCtx(ws))
    srv.close()
    expect(r.content).toContain('HTTP 200')
    expect(r.content).toContain('pong')
    expect(seen).toBe('POST /echo?q=me abc {"who":"me"}')
  })
  it('validates names and schemas', () => {
    expect(customToolImpl({ ...base, name: 'bad name', impl: { type: 'javascript', code: '', timeoutSec: 5 } }).error).toMatch(/Name/)
    expect(customToolImpl({ ...base, parameters: '{nope', impl: { type: 'javascript', code: '', timeoutSec: 5 } }).error).toBeTruthy()
    expect(customToolImpl({ ...base, impl: { type: 'javascript', code: '', timeoutSec: 5 } }).tool?.name).toBe('my_tool')
  })
})

describe('utilities', () => {
  it('globs', () => {
    expect(globToRegExp('**/*.{ts,tsx}').test('src/a/b.tsx')).toBe(true)
    expect(globToRegExp('**/*.ts').test('a.ts')).toBe(true)
    expect(matchGlob('*.md', 'docs/readme.md')).toBe(true)
    expect(matchGlob('src/*.ts', 'src/a/b.ts')).toBe(false)
    expect(matchGlob('README?', 'readme1')).toBe(true)
  })
  it('diffs', () => {
    const d = makeDiff('a\nb\nc\nd\ne\nf\ng\nh\ni\nj', 'a\nb\nc\nd\nE\nf\ng\nh\ni\nj', 2)
    expect(d).toContain('-e')
    expect(d).toContain('+E')
    expect(d).not.toContain(' a')
    expect(makeDiff('same', 'same')).toBe('(no changes)')
  })
  it('converts html to text', () => {
    const t = htmlToText('<html><head><title>x</title><style>p{}</style></head><body><h1>Hi &amp; bye</h1><p>One<br>Two</p><ul><li>a</li><li>b</li></ul><a href="https://e.com">link</a><script>evil()</script></body></html>')
    expect(t).toContain('# Hi & bye')
    expect(t).toContain('- a')
    expect(t).toContain('link (https://e.com)')
    expect(t).not.toContain('evil')
  })
  it('repairs sloppy tool-call JSON', () => {
    expect(parseToolArgs('{"a":1,}')).toEqual({ ok: true, value: { a: 1 } })
    expect(parseToolArgs('```json\n{"a":"b"}\n```')).toEqual({ ok: true, value: { a: 'b' } })
    expect(parseToolArgs('{"a":{"b":[1,2')).toEqual({ ok: true, value: { a: { b: [1, 2] } } })
    expect(parseToolArgs('')).toEqual({ ok: true, value: {} })
    expect(parseToolArgs('not json').ok).toBe(false)
  })
  it('detects private hosts', () => {
    for (const h of ['localhost', '127.0.0.1', '192.168.1.5', '10.0.0.2', '172.20.1.1', '169.254.1.1', 'nas.local', '[::1]']) expect(isPrivateHost(h)).toBe(true)
    for (const h of ['example.com', '8.8.8.8', 'fcbarcelona.com', '172.32.0.1']) expect(isPrivateHost(h)).toBe(false)
  })
  it('parses DuckDuckGo results', () => {
    const html = '<a class="result__a" href="//duckduckgo.com/l/?uddg=https%3A%2F%2Fexample.com%2Fa%3Fx%3D1&amp;rut=zz">Example <b>A</b></a><a class="result__snippet" href="#">Snippet &amp; text</a>'
    expect(parseDuckDuckGo(html)).toEqual([{ title: 'Example A', url: 'https://example.com/a?x=1', snippet: 'Snippet & text' }])
  })
  it('detects image requests', () => {
    expect(detectImageRequest('Generate an image of a snowy peak at dawn')).toBe('a snowy peak at dawn')
    expect(detectImageRequest('can you draw me a fox in a forest?')).toBe('a fox in a forest')
    expect(detectImageRequest('/imagine neon city')).toBe('neon city')
    expect(detectImageRequest('create a picture of a dog')).toBe('a dog')
    expect(detectImageRequest('how do I generate an image in python?')).toBeNull()
    expect(detectImageRequest('What is the capital of France?')).toBeNull()
  })
})

describe('context fitting', () => {
  const m = (role: ChatMessage['role'], content: string, extra: Partial<ChatMessage> = {}): ChatMessage => ({ id: Math.random().toString(), role, createdAt: 0, content, ...extra })
  it('drops oldest turns but keeps the latest and pairs tool calls', () => {
    const big = 'x'.repeat(3600) // ~1000 tokens
    const msgs = [
      m('user', big), m('assistant', big),
      m('user', big), m('assistant', '', { toolCalls: [{ id: 'c', name: 't', arguments: '{}' }] }), m('tool', big, { toolCallId: 'c' }), m('assistant', big),
      m('user', 'latest question')
    ]
    const out = fitHistory(msgs, 1500, 2)
    expect(out[out.length - 1].content).toBe('latest question')
    expect(out[0].role).toBe('user')
    expect(out.length).toBeLessThan(msgs.length)
  })
  it('flattens tool traffic when tools are off', () => {
    const msgs = [m('user', 'hi'), m('assistant', 'sure', { toolCalls: [{ id: 'c', name: 't', arguments: '{}' }] }), m('tool', 'out', { toolCallId: 'c' }), m('assistant', '', { toolCalls: [{ id: 'd', name: 't', arguments: '{}' }] })]
    const out = historyFor(msgs, false)
    expect(out.map((x) => x.role)).toEqual(['user', 'assistant'])
    expect(out[1].toolCalls).toBeUndefined()
  })
})
