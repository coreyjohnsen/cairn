import { Dices, ImagePlus, MountainSnow, RotateCcw, Search, Sparkles, Star, X } from 'lucide-react'
import { useMemo, useState } from 'react'
import { Ridgeline } from '@/components/Ridgeline'
import { Button, EmptyState, Field, IconButton, Notice, NumberField, Progress, Segmented, Select, Slider, Spinner, TextField } from '@/components/ui'
import { invoke, mediaUrl } from '@/lib/api'
import { RATIOS, SAMPLERS, describeSize, resolveSize } from '@/lib/imageSize'
import { cx, errorText } from '@/lib/format'
import { useApp } from '@/store/app'
import { targetKeyOf, useImages } from '@/store/images'
import type { ImageJob, ImageRecord } from '@shared/types'

/* ───────────── create panel ───────────── */

function CreatePanel() {
  const settings = useApp((s) => s.settings)!
  const setView = useApp((s) => s.setView)
  const toast = useApp((s) => s.toast)
  const form = useImages((s) => s.form)
  const setForm = useImages((s) => s.setForm)
  const targets = useImages((s) => s.targets)
  const loading = useImages((s) => s.targetsLoading)
  const refreshTargets = useImages((s) => s.refreshTargets)
  const generate = useImages((s) => s.generate)
  const records = useImages((s) => s.records)
  const busyJobs = useImages((s) => Object.values(s.jobs).filter((j) => j.status === 'queued' || j.status === 'running').length)
  const [enhancing, setEnhancing] = useState(false)
  const [before, setBefore] = useState<string | null>(null)
  const [advanced, setAdvanced] = useState(false)

  const def = settings.image.defaultTarget
  const target =
    targets.find((t) => targetKeyOf(t) === form.targetKey) ??
    (def ? targets.find((t) => t.backendId === def.backendId && t.model === def.model && t.available) : undefined) ??
    targets.find((t) => t.available) ??
    targets[0]
  const ready = !!target?.available
  const init = form.initImageId ? records.find((r) => r.id === form.initImageId) : undefined
  const img2img = !!init && !!target?.supportsImg2Img
  const negative = form.negative ?? settings.image.negativePrompt
  const d = target?.defaults

  const submit = async () => {
    if (!target || !ready) return
    const prompt = form.prompt.trim()
    if (!prompt) return
    const size = resolveSize(form, target)
    await generate({
      prompt,
      negativePrompt: target.supportsNegative && negative.trim() ? negative.trim() : undefined,
      target: { backendId: target.backendId, model: target.model },
      width: size.width,
      height: size.height,
      steps: form.steps,
      cfgScale: form.cfg,
      sampler: form.sampler,
      seed: form.seed,
      count: form.count,
      initImageId: img2img ? form.initImageId : undefined,
      strength: img2img ? form.strength : undefined
    })
  }

  const enhance = async () => {
    const p = form.prompt.trim()
    if (!p) return
    setEnhancing(true)
    try {
      const out = await invoke('chat:enhance', p)
      if (out && out.trim()) {
        setBefore(form.prompt)
        setForm({ prompt: out.trim() })
      }
    } catch (e) {
      toast('error', errorText(e))
    } finally {
      setEnhancing(false)
    }
  }

  return (
    <aside className="create-panel">
      <div className="create-scroll">
        <div className="create-title">
          <h2>Create</h2>
          {busyJobs > 0 && (
            <span className="badge badge-accent">
              <Spinner size={11} /> {busyJobs} in progress
            </span>
          )}
        </div>

        <Field
          label="Prompt"
          hint={
            before !== null ? (
              <button type="button" className="link-btn" onClick={() => { setForm({ prompt: before }); setBefore(null) }}>
                Undo enhancement
              </button>
            ) : undefined
          }
        >
          <div className="prompt-box">
            <textarea
              className="prompt-input"
              rows={5}
              value={form.prompt}
              placeholder="A lone cabin below a snow-dusted ridge at dawn, mist in the valley…"
              onChange={(e) => setForm({ prompt: e.target.value })}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && (e.ctrlKey || e.metaKey)) {
                  e.preventDefault()
                  void submit()
                }
              }}
              spellCheck
            />
            <div className="prompt-tools">
              <Button variant="ghost" size="sm" icon={<Sparkles size={14} />} busy={enhancing} disabled={!form.prompt.trim()} onClick={() => void enhance()} title="Let your chat model rewrite the prompt with more visual detail">
                Enhance
              </Button>
            </div>
          </div>
        </Field>

        <Field label="Model" hint={loading ? 'Looking…' : undefined}>
          <div className="row">
            <Select
              className="grow"
              value={target ? targetKeyOf(target) : ''}
              onChange={(v) => setForm({ targetKey: v })}
              options={targets.length ? targets.map((t) => ({ value: targetKeyOf(t), label: `${t.label}${t.available ? '' : ' (not ready)'}` })) : [{ value: '', label: 'No image models yet' }]}
              disabled={targets.length === 0}
            />
            <IconButton label="Refresh" size="sm" onClick={() => void refreshTargets(true)}>
              <RotateCcw size={15} />
            </IconButton>
          </div>
        </Field>

        {targets.length === 0 && (
          <Notice tone="info" action={<Button size="sm" onClick={() => setView('models', 'image')}>Set up</Button>}>
            Add an image model to start. The built-in engine runs on your GPU, or connect ComfyUI, AUTOMATIC1111 or an API.
          </Notice>
        )}
        {target && !target.available && (
          <Notice tone="warn" action={<Button size="sm" onClick={() => setView('models', 'image')}>Fix</Button>}>
            {target.unavailableReason ?? 'This model is not ready.'}
          </Notice>
        )}

        {target?.supportsNegative && (
          <Field label="Avoid">
            <TextField multiline rows={2} value={negative} placeholder="blurry, low quality, watermark" onCommit={(v) => setForm({ negative: v })} spellCheck />
          </Field>
        )}

        <Field label="Shape" hint={describeSize(form, target)}>
          <div className="ratio-grid">
            {RATIOS.map((r) => (
              <button key={r.id} type="button" className={cx('ratio', form.ratio === r.id && 'on')} onClick={() => setForm({ ratio: r.id })}>
                {r.id !== 'auto' && r.id !== 'custom' && <span className="ratio-box" style={{ aspectRatio: `${r.rw} / ${r.rh}` }} />}
                <span>{r.label}</span>
              </button>
            ))}
          </div>
          {form.ratio === 'custom' && (
            <div className="row" style={{ marginTop: 8 }}>
              <NumberField value={form.customW} min={64} max={2048} step={64} suffix="w" onCommit={(v) => setForm({ customW: v })} />
              <span className="faint">×</span>
              <NumberField value={form.customH} min={64} max={2048} step={64} suffix="h" onCommit={(v) => setForm({ customH: v })} />
            </div>
          )}
        </Field>

        <Field label="How many">
          <Segmented size="sm" value={String(form.count)} onChange={(v) => setForm({ count: Number(v) })} options={['1', '2', '4', '8'].map((n) => ({ value: n, label: n }))} />
        </Field>

        {init && (
          <Field label="Starting image" hint={target && !target.supportsImg2Img ? 'This model cannot start from an image.' : undefined}>
            <div className="init-card">
              <img src={mediaUrl('thumb', init.thumb)} alt="" draggable={false} />
              <div className="grow">
                <div className="small dim">Strength</div>
                <Slider value={form.strength} min={0.05} max={1} step={0.05} onChange={(v) => setForm({ strength: v })} format={(v) => v.toFixed(2)} />
              </div>
              <IconButton label="Remove" size="sm" onClick={() => setForm({ initImageId: undefined })}>
                <X size={15} />
              </IconButton>
            </div>
          </Field>
        )}

        <button type="button" className="adv-toggle" onClick={() => setAdvanced((a) => !a)} aria-expanded={advanced}>
          <span>Advanced</span>
          <span className="faint xs">{advanced ? 'Hide' : 'Steps, guidance, sampler, seed'}</span>
        </button>
        {advanced && (
          <div className="stack" style={{ gap: 16 }}>
            <Field label="Steps" hint={form.steps === undefined ? `Model default${d ? ` (${d.steps})` : ''}` : undefined}>
              <div className="row">
                <Slider value={form.steps ?? d?.steps ?? 25} min={1} max={100} onChange={(v) => setForm({ steps: v })} />
                {form.steps !== undefined && <button type="button" className="link-btn" onClick={() => setForm({ steps: undefined })}>Reset</button>}
              </div>
            </Field>
            <Field label="Guidance" hint={form.cfg === undefined ? `Model default${d ? ` (${d.cfg})` : ''}` : undefined}>
              <div className="row">
                <Slider value={form.cfg ?? d?.cfg ?? 7} min={0} max={20} step={0.5} onChange={(v) => setForm({ cfg: v })} format={(v) => v.toFixed(1)} />
                {form.cfg !== undefined && <button type="button" className="link-btn" onClick={() => setForm({ cfg: undefined })}>Reset</button>}
              </div>
            </Field>
            <Field label="Sampler">
              <Select
                value={form.sampler ?? ''}
                onChange={(v) => setForm({ sampler: v || undefined })}
                options={[{ value: '', label: d ? `Model default (${d.sampler})` : 'Model default' }, ...SAMPLERS.map((s) => ({ value: s, label: s }))]}
              />
            </Field>
            <Field label="Seed" hint="-1 picks a new one every time.">
              <div className="row">
                <NumberField value={form.seed} min={-1} max={4294967295} onCommit={(v) => setForm({ seed: v })} className="seed-field" />
                <IconButton label="Random seed" size="sm" onClick={() => setForm({ seed: -1 })}>
                  <Dices size={16} />
                </IconButton>
              </div>
            </Field>
          </div>
        )}
      </div>
      <div className="create-foot">
        <Button variant="primary" size="lg" className="create-go" icon={<ImagePlus size={18} />} disabled={!ready || !form.prompt.trim()} onClick={() => void submit()}>
          {busyJobs > 0 ? 'Add to queue' : 'Generate'}
        </Button>
        <div className="faint xs" style={{ textAlign: 'center', marginTop: 8 }}>
          Ctrl+Enter to generate
        </div>
      </div>
    </aside>
  )
}

/* ───────────── gallery ───────────── */

type Filter = 'all' | 'favorites' | 'chat'

function JobTile({ job }: { job: ImageJob }) {
  const cancel = useImages((s) => s.cancel)
  const dismiss = useImages((s) => s.dismissJob)
  const generate = useImages((s) => s.generate)
  const w = job.request.width || 1
  const h = job.request.height || 1
  const failed = job.status === 'error'
  return (
    <div className={cx('tile job', failed && 'failed')} style={{ aspectRatio: job.request.width && job.request.height ? `${w} / ${h}` : '1 / 1' }}>
      {!failed && <div className="gen-shimmer" />}
      <div className="job-body">
        {failed ? (
          <>
            <div className="small selectable job-err">{job.error ?? 'Generation failed.'}</div>
            <div className="row">
              <Button size="sm" onClick={() => { const { source: _s, ...rest } = job.request; void generate(rest); dismiss(job.id) }}>Retry</Button>
              <Button size="sm" variant="ghost" onClick={() => dismiss(job.id)}>Dismiss</Button>
            </div>
          </>
        ) : (
          <>
            <div className="job-prompt small dim">{job.request.prompt}</div>
            <div className="job-foot">
              <span className="xs faint">{job.status === 'queued' ? 'Waiting in queue' : (job.label ?? 'Generating…')}</span>
              <Progress value={job.progress} indeterminate={job.status === 'queued' || job.progress <= 0} height={4} />
            </div>
            <IconButton label="Cancel" size="sm" className="job-x" onClick={() => cancel(job.id)}>
              <X size={14} />
            </IconButton>
          </>
        )}
      </div>
    </div>
  )
}

function Tile({ rec, ids }: { rec: ImageRecord; ids: string[] }) {
  const view = useImages((s) => s.view)
  const favorite = useImages((s) => s.favorite)
  return (
    <div className="tile" style={{ aspectRatio: `${rec.width} / ${rec.height}` }}>
      <button type="button" className="tile-img" onClick={() => view(rec.id, ids)} aria-label={`Open: ${rec.prompt}`}>
        <img src={mediaUrl('thumb', rec.thumb)} alt={rec.prompt} loading="lazy" draggable={false} />
      </button>
      <div className="tile-over">
        <span className="tile-prompt">{rec.prompt}</span>
      </div>
      <button type="button" className={cx('tile-fav', rec.favorite && 'on')} aria-label={rec.favorite ? 'Remove from favorites' : 'Add to favorites'} onClick={() => favorite(rec.id, !rec.favorite)}>
        <Star size={15} fill={rec.favorite ? 'currentColor' : 'none'} />
      </button>
    </div>
  )
}

function Gallery() {
  const records = useImages((s) => s.records)
  const jobs = useImages((s) => s.jobs)
  const dismissed = useImages((s) => s.dismissed)
  const hasTargets = useImages((s) => s.targets.some((t) => t.available))
  const setView = useApp((s) => s.setView)
  const [filter, setFilter] = useState<Filter>('all')
  const [query, setQuery] = useState('')

  const shown = useMemo(() => {
    const q = query.trim().toLowerCase()
    return records.filter((r) => (filter === 'favorites' ? r.favorite : filter === 'chat' ? r.source === 'chat' : true) && (!q || r.prompt.toLowerCase().includes(q) || r.model.toLowerCase().includes(q)))
  }, [records, filter, query])
  const ids = useMemo(() => shown.map((r) => r.id), [shown])
  const live = Object.values(jobs)
    .filter((j) => (j.status === 'queued' || j.status === 'running' || j.status === 'error') && !dismissed[j.id] && j.request.source === 'hub')
    .sort((a, b) => b.createdAt - a.createdAt)

  return (
    <section className="gallery-wrap">
      <div className="gallery-head">
        <div>
          <h1>Image Hub</h1>
          <p className="faint small">{records.length === 0 ? 'Everything you make lands here.' : `${records.length} image${records.length === 1 ? '' : 's'}`}</p>
        </div>
        <div className="row">
          <div className="conv-search gallery-search">
            <Search size={14} />
            <input placeholder="Search prompts" value={query} onChange={(e) => setQuery(e.target.value)} spellCheck={false} />
          </div>
          <Segmented size="sm" value={filter} onChange={setFilter} options={[{ value: 'all', label: 'All' }, { value: 'favorites', label: 'Favorites' }, { value: 'chat', label: 'From chats' }]} />
        </div>
      </div>
      <div className="gallery-scroll">
        {records.length === 0 && live.length === 0 ? (
          <div className="gallery-empty">
            <div className="chat-empty-ridge">
              <Ridgeline seed={23} layers={4} />
            </div>
            <EmptyState
              icon={<MountainSnow size={26} />}
              title="No pictures yet"
              action={!hasTargets ? <Button variant="primary" onClick={() => setView('models', 'image')}>Set up an image model</Button> : undefined}
            >
              {hasTargets ? 'Describe a scene on the left and press Generate. You can also ask for images in any chat.' : 'Add an image model first, then describe a scene and watch it appear here.'}
            </EmptyState>
          </div>
        ) : shown.length === 0 && live.length === 0 ? (
          <EmptyState icon={<Search size={24} />} title="Nothing matches">
            Try another word, or switch the filter.
          </EmptyState>
        ) : (
          <div className="gallery">
            {live.map((j) => (
              <JobTile key={j.id} job={j} />
            ))}
            {shown.map((r) => (
              <Tile key={r.id} rec={r} ids={ids} />
            ))}
          </div>
        )}
      </div>
    </section>
  )
}

export function ImagesView() {
  return (
    <div className="hub-layout">
      <CreatePanel />
      <Gallery />
    </div>
  )
}

