import { create } from 'zustand'
import type { ImageGenRequest, ImageJob, ImageRecord, ImageTargetOption } from '@shared/types'
import { invoke, on } from '@/lib/api'
import { errorText } from '@/lib/format'
import { useApp } from './app'

export type Ratio = 'auto' | '1:1' | '3:4' | '4:3' | '16:9' | '9:16' | 'custom'

/** The Image Hub's create panel. Lives in the store so "reuse settings" from anywhere can fill it in. */
export interface HubForm {
  prompt: string
  /** undefined = the default negative prompt from settings */
  negative?: string
  /** `${backendId}::${model}`; empty = default target */
  targetKey: string
  ratio: Ratio
  customW: number
  customH: number
  steps?: number
  cfg?: number
  sampler?: string
  seed: number
  count: number
  initImageId?: string
  strength: number
}

export const DEFAULT_FORM: HubForm = { prompt: '', targetKey: '', ratio: 'auto', customW: 1024, customH: 1024, seed: -1, count: 1, strength: 0.6 }

export const targetKeyOf = (t: { backendId: string; model: string }): string => `${t.backendId}::${t.model}`

interface ImagesState {
  records: ImageRecord[]
  jobs: Record<string, ImageJob>
  dismissed: Record<string, true>
  targets: ImageTargetOption[]
  targetsLoading: boolean
  form: HubForm
  /** Opened in the lightbox, with the ids it can step through. */
  viewing: string | null
  siblings: string[]
  init(): Promise<void>
  refreshTargets(force?: boolean): Promise<void>
  setForm(patch: Partial<HubForm>): void
  /** Copy a finished image's settings into the create panel. */
  reuse(rec: ImageRecord, opts?: { asInit?: boolean }): void
  generate(req: Omit<ImageGenRequest, 'source'>): Promise<string | null>
  cancel(jobId: string): void
  dismissJob(jobId: string): void
  remove(ids: string[]): Promise<void>
  favorite(id: string, fav: boolean): void
  view(id: string | null, siblings?: string[]): void
}

const byNewest = (a: ImageRecord, b: ImageRecord) => b.createdAt - a.createdAt

function ratioFor(w: number, h: number): Ratio {
  const r = w / h
  const near = (x: number) => Math.abs(r - x) < 0.02
  if (near(1)) return '1:1'
  if (near(3 / 4)) return '3:4'
  if (near(4 / 3)) return '4:3'
  if (near(16 / 9)) return '16:9'
  if (near(9 / 16)) return '9:16'
  return 'custom'
}

export const useImages = create<ImagesState>()((set, get) => ({
  records: [],
  jobs: {},
  dismissed: {},
  targets: [],
  targetsLoading: false,
  form: DEFAULT_FORM,
  viewing: null,
  siblings: [],

  async init() {
    on('images:added', (r) => set((s) => ({ records: [r, ...s.records.filter((x) => x.id !== r.id)].sort(byNewest) })))
    on('images:updated', (r) => set((s) => ({ records: s.records.map((x) => (x.id === r.id ? r : x)) })))
    on('images:removed', (ids) =>
      set((s) => ({ records: s.records.filter((x) => !ids.includes(x.id)), viewing: s.viewing && ids.includes(s.viewing) ? null : s.viewing, siblings: s.siblings.filter((x) => !ids.includes(x)) }))
    )
    on('images:job', (j) => set((s) => ({ jobs: { ...s.jobs, [j.id]: j } })))
    const [records, jobs] = await Promise.all([invoke('images:list'), invoke('images:jobs')])
    set({ records: records.sort(byNewest), jobs: Object.fromEntries(jobs.map((j) => [j.id, j])) })
    void get().refreshTargets()
  },

  async refreshTargets(force = false) {
    set({ targetsLoading: true })
    try {
      set({ targets: await invoke('images:targets', force) })
    } catch (e) {
      useApp.getState().toast('error', errorText(e))
    } finally {
      set({ targetsLoading: false })
    }
  },

  setForm(patch) {
    set((s) => ({ form: { ...s.form, ...patch } }))
  },

  reuse(rec, opts) {
    const key = targetKeyOf({ backendId: rec.backendId, model: rec.model })
    const known = get().targets.some((t) => targetKeyOf(t) === key)
    set((s) => ({
      form: {
        ...s.form,
        prompt: rec.prompt,
        negative: rec.negativePrompt,
        targetKey: known ? key : s.form.targetKey,
        ratio: ratioFor(rec.width, rec.height),
        customW: rec.width,
        customH: rec.height,
        steps: rec.steps,
        cfg: rec.cfgScale,
        sampler: rec.sampler,
        seed: rec.seed,
        count: 1,
        initImageId: opts?.asInit ? rec.id : undefined
      }
    }))
    useApp.getState().setView('images')
    set({ viewing: null })
  },

  async generate(req) {
    try {
      const { jobId } = await invoke('images:generate', { ...req, source: 'hub' })
      return jobId
    } catch (e) {
      useApp.getState().toast('error', errorText(e))
      return null
    }
  },

  cancel(jobId) {
    void invoke('images:cancel', jobId)
  },

  dismissJob(jobId) {
    set((s) => ({ dismissed: { ...s.dismissed, [jobId]: true } }))
  },

  async remove(ids) {
    try {
      await invoke('images:delete', ids)
    } catch (e) {
      useApp.getState().toast('error', errorText(e))
    }
  },

  favorite(id, fav) {
    set((s) => ({ records: s.records.map((r) => (r.id === id ? { ...r, favorite: fav } : r)) }))
    void invoke('images:favorite', id, fav)
  },

  view(id, siblings) {
    set({ viewing: id, siblings: id ? (siblings && siblings.includes(id) ? siblings : [id]) : [] })
  }
}))
