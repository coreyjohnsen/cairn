import type { ImageTargetOption } from '@shared/types'
import type { HubForm, Ratio } from '@/store/images'

export const RATIOS: { id: Ratio; label: string; rw: number; rh: number }[] = [
  { id: 'auto', label: 'Auto', rw: 1, rh: 1 },
  { id: '1:1', label: '1:1', rw: 1, rh: 1 },
  { id: '3:4', label: '3:4', rw: 3, rh: 4 },
  { id: '4:3', label: '4:3', rw: 4, rh: 3 },
  { id: '16:9', label: '16:9', rw: 16, rh: 9 },
  { id: '9:16', label: '9:16', rw: 9, rh: 16 },
  { id: 'custom', label: 'Custom', rw: 1, rh: 1 }
]

export const SAMPLERS = ['euler_a', 'euler', 'heun', 'dpm2', 'dpm++2s_a', 'dpm++2m', 'dpm++2mv2', 'lcm']

const round64 = (n: number) => Math.max(256, Math.min(2048, Math.round(n / 64) * 64))

/** Pixel size for the chosen aspect ratio, keeping roughly the area the model was trained for. */
export function resolveSize(form: Pick<HubForm, 'ratio' | 'customW' | 'customH'>, target?: ImageTargetOption): { width: number; height: number } {
  if (form.ratio === 'auto') return { width: 0, height: 0 }
  if (form.ratio === 'custom') return { width: form.customW, height: form.customH }
  const r = RATIOS.find((x) => x.id === form.ratio) ?? RATIOS[1]
  const d = target?.defaults
  const base = d ? Math.sqrt(d.width * d.height) : 1024
  const w = Math.sqrt(base * base * (r.rw / r.rh))
  return { width: round64(w), height: round64((w * r.rh) / r.rw) }
}

export function describeSize(form: Pick<HubForm, 'ratio' | 'customW' | 'customH'>, target?: ImageTargetOption): string {
  const s = resolveSize(form, target)
  if (s.width === 0) return target?.defaults ? `${target.defaults.width} × ${target.defaults.height} (model default)` : 'Model default'
  return `${s.width} × ${s.height}`
}
