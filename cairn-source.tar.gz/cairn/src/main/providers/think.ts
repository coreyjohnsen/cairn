const OPEN = '<think>'
const CLOSE = '</think>'

export interface Split {
  text: string
  reasoning: string
}

/**
 * Streaming splitter that moves <think>…</think> sections out of normal text.
 * Tags may be split across chunks, so potential partial tags are held back.
 */
export class ThinkSplitter {
  private buf = ''
  private inThink = false

  push(chunk: string): Split {
    this.buf += chunk
    return this.drain(false)
  }

  flush(): Split {
    return this.drain(true)
  }

  private drain(final: boolean): Split {
    let text = ''
    let reasoning = ''
    for (;;) {
      const tag = this.inThink ? CLOSE : OPEN
      const idx = this.buf.indexOf(tag)
      if (idx >= 0) {
        const before = this.buf.slice(0, idx)
        if (this.inThink) reasoning += before
        else text += before
        this.buf = this.buf.slice(idx + tag.length)
        this.inThink = !this.inThink
        continue
      }
      // No complete tag: emit everything except a possible partial tag at the end.
      let keep = 0
      if (!final) {
        const max = Math.min(tag.length - 1, this.buf.length)
        for (let k = max; k > 0; k--) {
          if (tag.startsWith(this.buf.slice(this.buf.length - k))) {
            keep = k
            break
          }
        }
      }
      const emit = this.buf.slice(0, this.buf.length - keep)
      this.buf = this.buf.slice(this.buf.length - keep)
      if (this.inThink) reasoning += emit
      else text += emit
      break
    }
    return { text, reasoning }
  }
}
