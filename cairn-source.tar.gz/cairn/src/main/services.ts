import type { Settings, ToolPermission } from '@shared/types'
import { ApprovalManager } from './agent/approvals'
import { ChatRunner } from './agent/runner'
import { AttachmentStore } from './attachments'
import { ConversationStore } from './conversations'
import { DownloadManager } from './engines/downloads'
import { EngineManager } from './engines/manager'
import { LlamaManager } from './engines/llama-server'
import { LocalProvider } from './engines/local-provider'
import { emit } from './events'
import { ImageService } from './images/service'
import { ImageStore } from './images/store'
import { ModelService } from './models'
import { initPaths, type AppPaths } from './paths'
import { type Cipher, setCipher } from './secrets'
import { SettingsStore } from './settings'
import { McpManager } from './tools/mcp'
import { ToolRegistry } from './tools/registry'

export interface ServiceOptions {
  dataDir: string
  cipher?: Cipher | null
  /** JPEG thumbnail maker (Electron nativeImage in the app). */
  makeThumb?: (data: Uint8Array, maxEdge: number) => Uint8Array | null
  /** Downscaler for attached images (Electron nativeImage in the app). */
  prepareImage?: (data: Uint8Array, mime: string) => { data: Uint8Array; mime: string } | null
  /** Connect configured MCP servers at startup (disabled in tests). */
  startMcp?: boolean
}

export interface Services {
  paths: AppPaths
  settings: SettingsStore
  conversations: ConversationStore
  models: ModelService
  mcp: McpManager
  tools: ToolRegistry
  approvals: ApprovalManager
  engines: EngineManager
  llama: LlamaManager
  localProvider: LocalProvider
  downloads: DownloadManager
  imageStore: ImageStore
  images: ImageService
  attachments: AttachmentStore
  runner: ChatRunner
  shutdown(): Promise<void>
}

export async function createServices(opts: ServiceOptions): Promise<Services> {
  const paths = initPaths(opts.dataDir)
  setCipher(opts.cipher ?? null)

  const settings = new SettingsStore(paths.settingsFile, paths.defaultModels)
  await settings.load()
  const get = (): Settings => settings.get()

  const conversations = new ConversationStore(paths.conversations)
  await conversations.init()

  // Services reference each other through late-bound closures.
  const ref: { images?: ImageService; models?: ModelService; local?: LocalProvider } = {}

  const engines = new EngineManager({
    getSettings: get,
    updateSettings: (patch) => settings.update(patch),
    paths,
    onProgress: (p) => emit('engines:progress', p),
    onChanged: (id) => {
      emit('engines:changed', id)
      ref.images?.invalidate()
      ref.models?.invalidate()
    }
  })
  await engines.init()

  const llama = new LlamaManager({ getSettings: get, engines })
  const localProvider = new LocalProvider({ getSettings: get, modelsDir: () => settings.modelsDir(), llama })
  ref.local = localProvider
  const models = new ModelService(get, localProvider)
  ref.models = models

  const mcp = new McpManager(get)
  const tools = new ToolRegistry(get, mcp)
  const approvals = new ApprovalManager()

  const imageStore = new ImageStore({ imagesDir: paths.images, thumbsDir: paths.thumbs, indexFile: paths.imageIndex, makeThumb: opts.makeThumb })
  await imageStore.load()
  const images = new ImageService({ getSettings: get, store: imageStore, engines, llama, tmpDir: paths.tmp })
  ref.images = images

  const attachments = new AttachmentStore({ dir: paths.attachments, prepareImage: opts.prepareImage })

  const downloads = new DownloadManager({
    getSettings: get,
    modelsDir: () => settings.modelsDir(),
    onUpdate: (item) => {
      emit('downloads:update', item)
      if (item.status === 'done') {
        localProvider.invalidate()
        models.invalidate('local')
      }
    }
  })

  const runner = new ChatRunner({
    getSettings: get,
    setToolPermission: (name: string, permission: ToolPermission) => {
      const s = get()
      settings.update({ agent: { ...s.agent, toolPermissions: { ...s.agent.toolPermissions, [name]: permission } } })
    },
    conversations,
    models,
    tools,
    approvals,
    images,
    attachments,
    emit: (e) => emit('chat:event', e)
  })

  // React to the parts of settings that have live side effects, ignoring unrelated edits.
  const sig = (s: Settings) => ({ providers: JSON.stringify(s.providers), mcp: JSON.stringify(s.mcpServers), image: JSON.stringify(s.image), paths: JSON.stringify([s.paths.modelsDir, s.paths.extraModelDirs]) })
  let last = sig(get())
  settings.onChange((s) => {
    const now = sig(s)
    if (now.providers !== last.providers) models.invalidate()
    if (now.image !== last.image) images.invalidate()
    if (now.paths !== last.paths) {
      localProvider.invalidate()
      models.invalidate('local')
    }
    if (now.mcp !== last.mcp) void mcp.sync().catch(() => {})
    last = now
  })
  if (opts.startMcp !== false) void mcp.sync().catch(() => {})

  return {
    paths,
    settings,
    conversations,
    models,
    mcp,
    tools,
    approvals,
    engines,
    llama,
    localProvider,
    downloads,
    imageStore,
    images,
    attachments,
    runner,
    async shutdown() {
      runner.abortAll()
      downloads.cancelAll()
      await Promise.allSettled([mcp.closeAll(), llama.stop()])
      await Promise.allSettled([settings.saveNow(), conversations.flush(), imageStore.flush()])
    }
  }
}
