import type { ImageBackendConfig, ImageGenRequest, ImageJob, ImageRecord, ImageRef, ImageTargetOption, Settings } from '@shared/types'
import { newId } from '@shared/defaults'
import { emit } from '../events'
import type { EngineManager } from '../engines/manager'
import type { ImageApi } from '../agent/runner'
import { A1111Backend } from './a1111'
import { ComfyBackend } from './comfyui'
import { OpenAIImagesBackend } from './openai-images'
import { SdCppBackend } from './sdcpp'
import { imageSize } from './size'
import type { ImageStore } from './store'
import { BackendError, type BackendModel, type GenParams, type ImageBackend, randomSeed } from './types'

export interface ImageServiceDeps {
  getSettings(): Settings
  store: ImageStore
  engines: EngineManager
  llama: { unloadForImages(): Promise<boolean> }
  tmpDir: string
  /** Test seam: replace backend construction. */
  makeBackend?: (cfg: ImageBackendConfig) => ImageBackend
}

interface JobEntry {
  job: ImageJob
  controller: AbortController
  listeners: Set<(fraction: number, label?: string) => void>
  promise: Promise<ImageRecord[]>
  resolve(v: ImageRecord[]): void
  reject(e: unknown): void
  lastEmit: number
}

const TARGET_TTL_MS = 30_000
const KEEP_FINISHED_JOBS = 40
const FALLBACK_SIZE = 768

const clamp = (n: number, lo: number, hi: number) => Math.min(hi, Math.max(lo, n))
const snap8 = (n: number) => clamp(Math.round(n / 8) * 8, 64, 2048)

function withTimeout<T>(p: Promise<T>, ms: number, what: string): Promise<T> {
  return new Promise<T>((resolve, reject) => {
    const t = setTimeout(() => reject(new Error(`${what} timed out`)), ms)
    p.then(
      (v) => {
        clearTimeout(t)
        resolve(v)
      },
      (e) => {
        clearTimeout(t)
        reject(e)
      }
    )
  })
}

export function toRef(r: ImageRecord): ImageRef {
  return { id: r.id, file: r.file, thumb: r.thumb, prompt: r.prompt, width: r.width, height: r.height }
}

export class ImageService implements ImageApi {
  private jobs = new Map<string, JobEntry>()
  private queue: string[] = []
  private pumping = false
  private targetCache = new Map<string, { at: number; options: ImageTargetOption[] }>()

  constructor(private d: ImageServiceDeps) {}

  /* ───────────────────────────── backends & targets ───────────────────────────── */

  private backend(cfg: ImageBackendConfig): ImageBackend {
    if (this.d.makeBackend) return this.d.makeBackend(cfg)
    switch (cfg.kind) {
      case 'builtin':
        return new SdCppBackend({ getSettings: this.d.getSettings, engines: this.d.engines, tmpDir: this.d.tmpDir })
      case 'comfyui':
        return new ComfyBackend(cfg)
      case 'a1111':
        return new A1111Backend(cfg)
      case 'openai':
        return new OpenAIImagesBackend(cfg)
    }
  }

  invalidate(): void {
    this.targetCache.clear()
  }

  /** Cheap synchronous check used to decide whether the model is offered the generate_image tool. */
  available(): boolean {
    const s = this.d.getSettings()
    return s.image.backends.some((b) => {
      if (!b.enabled) return false
      if (b.kind === 'builtin') return s.image.localModels.length > 0 && !!this.d.engines.resolveBinary('sd')
      if (b.kind === 'openai') return !!b.apiKey || !!b.baseUrl
      return !!b.baseUrl
    })
  }

  private async optionsFor(cfg: ImageBackendConfig, force: boolean): Promise<ImageTargetOption[]> {
    const cached = this.targetCache.get(cfg.id)
    if (!force && cached && Date.now() - cached.at < TARGET_TTL_MS) return cached.options

    const base = { backendId: cfg.id, backendName: cfg.name, kind: cfg.kind }
    const be = this.backend(cfg)
    let options: ImageTargetOption[]
    try {
      let reason: string | undefined
      if (cfg.kind === 'builtin' && !this.d.engines.resolveBinary('sd')) reason = 'The image engine is not installed yet (Models → Engines).'
      const models: BackendModel[] = await withTimeout(be.listModels(), 6000, `${cfg.name}`)
      if (!models.length) {
        options = [
          {
            ...base,
            model: '',
            label: cfg.name,
            supportsImg2Img: be.supportsImg2Img,
            supportsNegative: be.supportsNegative,
            available: false,
            unavailableReason: cfg.kind === 'builtin' ? 'No image models yet. Add one in Models → Image models.' : 'No models were reported by this backend.'
          }
        ]
      } else {
        options = models.map((m) => ({
          ...base,
          model: m.id,
          label: m.label,
          supportsImg2Img: be.supportsImg2Img,
          supportsNegative: be.supportsNegative,
          defaults: m.defaults,
          available: !reason,
          unavailableReason: reason
        }))
      }
    } catch (e) {
      options = [
        {
          ...base,
          model: cfg.defaultModel,
          label: cfg.name,
          supportsImg2Img: be.supportsImg2Img,
          supportsNegative: be.supportsNegative,
          available: false,
          unavailableReason: e instanceof Error ? e.message : String(e)
        }
      ]
    }
    this.targetCache.set(cfg.id, { at: Date.now(), options })
    return options
  }

  async targets(force = false): Promise<ImageTargetOption[]> {
    const s = this.d.getSettings()
    const live = new Set(s.image.backends.map((b) => b.id))
    for (const id of [...this.targetCache.keys()]) if (!live.has(id)) this.targetCache.delete(id)
    const groups = await Promise.all(s.image.backends.filter((b) => b.enabled).map((b) => this.optionsFor(b, force)))
    return groups.flat()
  }

  async testBackend(backendId: string): Promise<{ ok: boolean; message: string }> {
    const cfg = this.d.getSettings().image.backends.find((b) => b.id === backendId)
    if (!cfg) return { ok: false, message: 'That connection no longer exists.' }
    try {
      const message = await withTimeout(this.backend(cfg).test(), 20_000, 'The connection test')
      this.targetCache.delete(cfg.id)
      return { ok: true, message }
    } catch (e) {
      return { ok: false, message: e instanceof Error ? e.message : String(e) }
    }
  }

  /* ───────────────────────────── jobs ───────────────────────────── */

  listJobs(): ImageJob[] {
    return [...this.jobs.values()].map((e) => e.job).sort((a, b) => b.createdAt - a.createdAt)
  }

  /** Queue a request and return immediately (used by the Image Hub). */
  submit(req: ImageGenRequest): ImageJob {
    return this.enqueue(req).job
  }

  /** Queue a request and wait for it (used by chat). */
  async generate(req: ImageGenRequest, hooks: { onProgress(fraction: number, label?: string): void; signal: AbortSignal }): Promise<ImageRef[]> {
    const entry = this.enqueue(req)
    entry.listeners.add(hooks.onProgress)
    const onAbort = () => this.cancel(entry.job.id)
    if (hooks.signal.aborted) onAbort()
    else hooks.signal.addEventListener('abort', onAbort, { once: true })
    try {
      return (await entry.promise).map(toRef)
    } finally {
      hooks.signal.removeEventListener('abort', onAbort)
      entry.listeners.delete(hooks.onProgress)
    }
  }

  cancel(jobId: string): void {
    const e = this.jobs.get(jobId)
    if (!e) return
    if (e.job.status === 'queued') {
      this.queue = this.queue.filter((id) => id !== jobId)
      this.finish(e, 'cancelled', undefined, new BackendError('Cancelled'))
    } else if (e.job.status === 'running') {
      e.controller.abort()
    }
  }

  private enqueue(req: ImageGenRequest): JobEntry {
    const prompt = (req.prompt ?? '').trim()
    let resolve!: (v: ImageRecord[]) => void
    let reject!: (e: unknown) => void
    const promise = new Promise<ImageRecord[]>((res, rej) => {
      resolve = res
      reject = rej
    })
    promise.catch(() => {}) // hub jobs have no awaiter; failures are reported through job events

    const entry: JobEntry = {
      job: { id: newId('job'), status: 'queued', request: { ...req, prompt }, progress: 0, resultIds: [], createdAt: Date.now() },
      controller: new AbortController(),
      listeners: new Set(),
      promise,
      resolve,
      reject,
      lastEmit: 0
    }
    this.jobs.set(entry.job.id, entry)
    emit('images:job', { ...entry.job })
    if (!prompt) {
      this.finish(entry, 'error', 'Describe the image you want first.', new BackendError('Describe the image you want first.'))
      return entry
    }
    this.queue.push(entry.job.id)
    void this.pump()
    return entry
  }

  private async pump(): Promise<void> {
    if (this.pumping) return
    this.pumping = true
    try {
      while (this.queue.length) {
        const id = this.queue.shift()!
        const e = this.jobs.get(id)
        if (!e || e.job.status !== 'queued') continue
        await this.runJob(e)
      }
    } finally {
      this.pumping = false
    }
  }

  private progress(e: JobEntry, fraction: number, label?: string): void {
    const f = clamp(Number.isFinite(fraction) ? fraction : 0, 0, 1)
    const labelChanged = label !== undefined && label !== e.job.label
    e.job.progress = Math.max(e.job.progress, f)
    if (label !== undefined) e.job.label = label
    for (const l of e.listeners) {
      try {
        l(e.job.progress, e.job.label)
      } catch {
        /* a listener must never break generation */
      }
    }
    const now = Date.now()
    if (labelChanged || now - e.lastEmit > 120) {
      e.lastEmit = now
      emit('images:job', { ...e.job })
    }
  }

  private finish(e: JobEntry, status: 'done' | 'error' | 'cancelled', error?: string, rejection?: unknown, records?: ImageRecord[]): void {
    e.job.status = status
    e.job.error = status === 'error' ? error : undefined
    e.job.label = status === 'done' ? 'Done' : status === 'cancelled' ? 'Cancelled' : e.job.label
    if (status === 'done') e.job.progress = 1
    e.job.resultIds = (records ?? []).map((r) => r.id)
    emit('images:job', { ...e.job })
    if (status === 'done') e.resolve(records ?? [])
    else e.reject(rejection ?? new BackendError(error ?? 'Failed'))
    this.trimJobs()
  }

  private trimJobs(): void {
    const finished = [...this.jobs.values()].filter((e) => e.job.status === 'done' || e.job.status === 'error' || e.job.status === 'cancelled').sort((a, b) => b.job.createdAt - a.job.createdAt)
    for (const e of finished.slice(KEEP_FINISHED_JOBS)) this.jobs.delete(e.job.id)
  }

  private async runJob(e: JobEntry): Promise<void> {
    e.job.status = 'running'
    e.job.progress = 0.01
    e.job.label = 'Starting…'
    emit('images:job', { ...e.job })
    try {
      const records = await this.execute(e)
      this.finish(e, 'done', undefined, undefined, records)
    } catch (err) {
      const msg = err instanceof Error ? err.message : String(err)
      if (e.controller.signal.aborted || msg === 'Cancelled') this.finish(e, 'cancelled', undefined, err)
      else this.finish(e, 'error', msg, err)
    }
  }

  /* ───────────────────────────── execution ───────────────────────────── */

  private async resolveTarget(req: ImageGenRequest): Promise<{ cfg: ImageBackendConfig; opt: ImageTargetOption | undefined; model: string }> {
    const s = this.d.getSettings()
    const options = await this.targets()
    const wanted = req.target ?? s.image.defaultTarget
    if (wanted) {
      const cfg = s.image.backends.find((b) => b.id === wanted.backendId)
      if (cfg && cfg.enabled) {
        const opt = options.find((o) => o.backendId === cfg.id && o.model === wanted.model)
        if (opt || wanted.model) return { cfg, opt, model: wanted.model }
      }
      // The saved default points at something that no longer exists: fall through to the first usable target.
    }
    const first = options.find((o) => o.available)
    if (first) {
      const cfg = s.image.backends.find((b) => b.id === first.backendId)!
      return { cfg, opt: first, model: first.model }
    }
    const why = options.find((o) => o.unavailableReason)?.unavailableReason
    throw new BackendError(`No image model is ready yet. ${why ?? 'Open the Image Hub and set one up under Models → Image models.'}`)
  }

  private async execute(e: JobEntry): Promise<ImageRecord[]> {
    const req = e.job.request
    const settings = this.d.getSettings()
    const { cfg, opt, model } = await this.resolveTarget(req)
    if (opt && !opt.available) throw new BackendError(opt.unavailableReason ?? `${cfg.name} is not available right now.`)
    if (!model && cfg.kind === 'builtin') throw new BackendError('Pick an image model first.')
    const be = this.backend(cfg)
    const signal = e.controller.signal
    if (signal.aborted) throw new BackendError('Cancelled')

    const d = opt?.defaults
    const official = cfg.kind === 'openai'
    const width = req.width > 0 ? req.width : d?.width ?? (official ? 1024 : FALLBACK_SIZE)
    const height = req.height > 0 ? req.height : d?.height ?? (official ? 1024 : FALLBACK_SIZE)
    const stepsWanted = req.steps ?? d?.steps ?? 0

    let initImage: Uint8Array | undefined
    if (req.initImageId) {
      if (!be.supportsImg2Img) throw new BackendError(`${cfg.name} does not support image-to-image. Choose a different image model for this.`)
      initImage = (await this.d.store.readBytes(req.initImageId)) ?? undefined
      if (!initImage) throw new BackendError('The source image for image-to-image no longer exists.')
    }

    const params: GenParams = {
      prompt: req.prompt,
      negative: be.supportsNegative ? (req.negativePrompt ?? settings.image.negativePrompt ?? '') : '',
      width: official ? width : snap8(width),
      height: official ? height : snap8(height),
      steps: stepsWanted > 0 ? Math.round(stepsWanted) : official ? 0 : 25,
      cfg: req.cfgScale ?? d?.cfg ?? 7,
      seed: req.seed >= 0 ? Math.floor(req.seed) : randomSeed(),
      sampler: req.sampler || d?.sampler || 'euler_a',
      count: clamp(Math.round(req.count || 1), 1, 8),
      model,
      initImage,
      strength: req.strength
    }

    if (cfg.kind === 'builtin' && settings.image.unloadLlmForImages) {
      this.progress(e, 0.01, 'Freeing GPU memory…')
      await this.d.llama.unloadForImages().catch(() => false)
    }

    const started = Date.now()
    const images = await be.generate(params, { signal, onProgress: (f, label) => this.progress(e, f, label) })
    if (signal.aborted) throw new BackendError('Cancelled')
    const durationMs = Date.now() - started

    const records: ImageRecord[] = []
    for (const img of images) {
      const size = imageSize(img.data)
      records.push(
        await this.d.store.add(img.data, {
          prompt: req.prompt,
          negativePrompt: params.negative,
          backendId: cfg.id,
          backendName: cfg.name,
          model: opt?.label ?? model,
          width: size?.width ?? params.width,
          height: size?.height ?? params.height,
          steps: params.steps || undefined,
          cfgScale: official ? undefined : params.cfg,
          seed: img.seed,
          sampler: official ? undefined : params.sampler,
          durationMs,
          source: req.source,
          conversationId: req.conversationId,
          initImageId: req.initImageId
        })
      )
    }
    return records
  }
}
