import { spawn } from 'node:child_process'
import fs from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'
import type { SdModelConfig, Settings } from '@shared/types'
import { splitArgs } from '../engines/library'
import type { EngineManager } from '../engines/manager'
import { killTree } from '../tools/shell'
import { type BackendHooks, type BackendImage, BackendError, type BackendModel, type GenParams, type ImageBackend } from './types'

export interface SdDeps {
  getSettings(): Settings
  engines: EngineManager
  tmpDir: string
}

const flagCache = new Map<string, Set<string> | null>()

/** Ask the binary which long flags it understands, so optional flags are only passed when supported. */
export async function probeFlags(binary: string, env: NodeJS.ProcessEnv): Promise<Set<string> | null> {
  if (flagCache.has(binary)) return flagCache.get(binary)!
  const text = await new Promise<string | null>((resolve) => {
    try {
      const p = spawn(binary, ['--help'], { env, windowsHide: true, cwd: path.dirname(binary), stdio: ['ignore', 'pipe', 'pipe'] })
      let out = ''
      p.stdout.on('data', (d) => (out += d))
      p.stderr.on('data', (d) => (out += d))
      const t = setTimeout(() => {
        killTree(p.pid)
        resolve(out || null)
      }, 8000)
      p.on('error', () => {
        clearTimeout(t)
        resolve(null)
      })
      p.on('close', () => {
        clearTimeout(t)
        resolve(out)
      })
    } catch {
      resolve(null)
    }
  })
  const flags = text ? new Set([...text.matchAll(/--[a-z][a-z0-9_-]+/gi)].map((m) => m[0])) : null
  const result = flags && flags.size > 5 ? flags : null
  flagCache.set(binary, result)
  return result
}

export function clearFlagCache(): void {
  flagCache.clear()
}

/** Build the sd-cli command line (pure; exported for tests). */
export function buildSdArgs(
  model: SdModelConfig,
  p: GenParams,
  outFile: string,
  supported: Set<string> | null,
  initPath?: string
): string[] {
  const ok = (flag: string) => !supported || supported.has(flag)
  const args: string[] = []
  if (model.model) args.push('-m', model.model)
  if (model.diffusionModel) args.push('--diffusion-model', model.diffusionModel)
  if (model.vae) args.push('--vae', model.vae)
  if (model.clipL) args.push('--clip_l', model.clipL)
  if (model.clipG) args.push('--clip_g', model.clipG)
  if (model.t5xxl) args.push('--t5xxl', model.t5xxl)
  args.push('-p', p.prompt)
  if (p.negative.trim()) args.push('-n', p.negative)
  args.push('-W', String(p.width), '-H', String(p.height))
  args.push('--steps', String(p.steps), '--cfg-scale', String(p.cfg))
  args.push('--sampling-method', p.sampler)
  args.push('-s', String(p.seed))
  if (p.count > 1) args.push('-b', String(p.count))
  args.push('-o', outFile)
  if (initPath) args.push('-i', initPath, '--strength', String(p.strength ?? 0.6))
  if (model.vaeTiling && ok('--vae-tiling')) args.push('--vae-tiling')
  if (model.offloadToCpu && ok('--offload-to-cpu')) args.push('--offload-to-cpu')
  if (model.clipOnCpu && ok('--clip-on-cpu')) args.push('--clip-on-cpu')
  if (model.flashAttn && ok('--diffusion-fa')) args.push('--diffusion-fa')
  args.push(...splitArgs(model.extraArgs))
  return args
}

/** Turn raw stderr into advice the user can act on. */
export function explainSdFailure(code: number | null, tail: string[]): string {
  const text = tail.join('\n')
  let hint = ''
  if (/out of memory|failed to allocate|alloc.*fail|ErrorOutOfDeviceMemory|bad_alloc|cudaMalloc failed/i.test(text)) {
    hint = '\n\nThe GPU ran out of memory. Try a smaller size, enable "VAE tiling" and "Offload to CPU" for this model, use a smaller or quantised model, or free VRAM by closing other GPU apps.'
  } else if (/unknown (argument|option)|invalid (argument|parameter)|unrecognized/i.test(text)) {
    hint = '\n\nThe engine did not recognise one of the arguments. Check "Extra arguments" for this model, or update the engine under Models → Engines.'
  } else if (/failed to (load|init)|get sd version from file failed|unknown model|load model.*failed/i.test(text)) {
    hint = '\n\nThe model could not be loaded. Make sure the model type matches the files (FLUX and SD3 need separate VAE/text-encoder files and use "Diffusion model" instead of "Checkpoint").'
  }
  return `stable-diffusion.cpp exited with code ${code}.\n${tail.slice(-8).join('\n')}${hint}`
}

const PROGRESS_RE = /(\d+)\s*\/\s*(\d+)\s*-\s*[\d.]+\s*(?:s\/it|it\/s)/

export class SdCppBackend implements ImageBackend {
  readonly supportsImg2Img = true
  readonly supportsNegative = true

  constructor(private d: SdDeps) {}

  async listModels(): Promise<BackendModel[]> {
    return this.d.getSettings().image.localModels.map((m) => ({
      id: m.id,
      label: m.name,
      defaults: { width: m.width, height: m.height, steps: m.steps, cfg: m.cfg, sampler: m.sampler }
    }))
  }

  private binary(): string {
    const bin = this.d.engines.resolveBinary('sd')
    if (!bin) throw new BackendError('The stable-diffusion.cpp engine is not installed. Open Models → Engines and install it (one click), or choose your own sd-cli binary.')
    return bin
  }

  async test(): Promise<string> {
    const bin = this.binary()
    const flags = await probeFlags(bin, this.d.engines.spawnEnv('sd', bin))
    const models = this.d.getSettings().image.localModels.length
    return `Engine found: ${path.basename(bin)}${flags ? ` (${flags.size} options detected)` : ''}. ${models} image model${models === 1 ? '' : 's'} configured.`
  }

  async generate(p: GenParams, hooks: BackendHooks): Promise<BackendImage[]> {
    const model = this.d.getSettings().image.localModels.find((m) => m.id === p.model)
    if (!model) throw new BackendError('That image model no longer exists. Pick another one.')
    if (!model.model && !model.diffusionModel) throw new BackendError(`"${model.name}" has no model file selected. Open Models → Image models and choose one.`)
    for (const f of [model.model, model.diffusionModel, model.vae, model.clipL, model.clipG, model.t5xxl]) {
      if (f && !fs.existsSync(f)) throw new BackendError(`Model file not found: ${f}`)
    }
    const bin = this.binary()
    const env = this.d.engines.spawnEnv('sd', bin)
    const supported = await probeFlags(bin, env)

    const work = await fsp.mkdtemp(path.join(this.d.tmpDir, 'sd-'))
    try {
      let initPath: string | undefined
      if (p.initImage) {
        initPath = path.join(work, 'init.png')
        await fsp.writeFile(initPath, p.initImage)
      }
      const outFile = path.join(work, 'out.png')
      const args = buildSdArgs(model, p, outFile, supported, initPath)

      await new Promise<void>((resolve, reject) => {
        const child = spawn(bin, args, { cwd: path.dirname(bin), env, windowsHide: true, detached: process.platform !== 'win32', stdio: ['ignore', 'pipe', 'pipe'] })
        const tail: string[] = []
        let lastStep = 0
        let imageIdx = 0
        const onAbort = () => killTree(child.pid)
        hooks.signal.addEventListener('abort', onAbort, { once: true })
        hooks.onProgress(0.02, 'Loading model…')
        const feed = (chunk: string) => {
          for (const piece of chunk.split(/[\r\n]+/)) {
            const line = piece.trim()
            if (!line) continue
            const m = PROGRESS_RE.exec(line)
            if (m) {
              const step = Number(m[1])
              const total = Math.max(1, Number(m[2]))
              if (step < lastStep) imageIdx++
              lastStep = step
              const frac = 0.08 + 0.88 * ((imageIdx + step / total) / Math.max(1, p.count))
              hooks.onProgress(Math.min(0.97, frac), `Sampling step ${step}/${total}${p.count > 1 ? ` · image ${imageIdx + 1}/${p.count}` : ''}`)
            } else {
              tail.push(line.slice(0, 300))
              if (tail.length > 40) tail.shift()
              if (/decoding|vae/i.test(line)) hooks.onProgress(0.97, 'Decoding image…')
            }
          }
        }
        child.stdout.setEncoding('utf8')
        child.stderr.setEncoding('utf8')
        child.stdout.on('data', feed)
        child.stderr.on('data', feed)
        child.on('error', (e) => {
          hooks.signal.removeEventListener('abort', onAbort)
          reject(new BackendError(`Could not start the image engine: ${e.message}`))
        })
        child.on('close', (code) => {
          hooks.signal.removeEventListener('abort', onAbort)
          if (hooks.signal.aborted) return reject(new BackendError('Cancelled'))
          if (code !== 0) return reject(new BackendError(explainSdFailure(code, tail)))
          resolve()
        })
      })

      const files = (await fsp.readdir(work))
        .filter((f) => /^out.*\.(png|jpg|jpeg|webp)$/i.test(f))
        .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }))
      if (!files.length) throw new BackendError('The engine finished but produced no image. Check the model files and settings.')
      const out: BackendImage[] = []
      for (let i = 0; i < files.length; i++) {
        out.push({ data: await fsp.readFile(path.join(work, files[i])), seed: p.seed + i })
      }
      hooks.onProgress(1, 'Done')
      return out
    } finally {
      await fsp.rm(work, { recursive: true, force: true }).catch(() => {})
    }
  }
}
