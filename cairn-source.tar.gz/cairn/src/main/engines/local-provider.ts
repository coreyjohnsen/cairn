import type { LocalModelFile, ProviderModel, Settings } from '@shared/types'
import { LOCAL_PROVIDER_ID } from '@shared/defaults'
import { OpenAIProvider } from '../providers/openai'
import type { Provider, ProviderRequest, StreamEvent } from '../providers/types'
import { scanGguf } from './library'
import type { LlamaManager } from './llama-server'

export interface LocalDeps {
  getSettings(): Settings
  modelsDir(): string
  llama: LlamaManager
}

export function llmRoots(modelsDir: string, extra: string[]): string[] {
  return [modelsDir, ...extra].filter(Boolean)
}

/**
 * The "This computer" provider: model ids are absolute GGUF paths. Sending a message loads the
 * model into the managed llama-server (starting/restarting it as needed) and talks to it over
 * the OpenAI-compatible API.
 */
export class LocalProvider implements Provider {
  readonly id = LOCAL_PROVIDER_ID
  private scanCache: { at: number; files: LocalModelFile[] } | null = null

  constructor(private d: LocalDeps) {}

  invalidate(): void {
    this.scanCache = null
  }

  async scan(force = false): Promise<LocalModelFile[]> {
    if (!force && this.scanCache && Date.now() - this.scanCache.at < 10_000) return this.scanCache.files
    const s = this.d.getSettings()
    const files = await scanGguf(llmRoots(this.d.modelsDir(), s.paths.extraModelDirs))
    this.scanCache = { at: Date.now(), files }
    return files
  }

  async listModels(): Promise<ProviderModel[]> {
    const ctx = this.d.getSettings().local.contextSize
    const files = await this.scan(true)
    return files.map((f) => ({
      id: f.path,
      name: f.quant ? `${f.name}` : f.name,
      vision: Boolean(f.mmprojPath),
      tools: true,
      reasoning: /think|reason|r1|qwq|qwen3|gpt-oss/i.test(f.name),
      contextLength: ctx > 0 ? ctx : undefined
    }))
  }

  async *stream(req: ProviderRequest): AsyncGenerator<StreamEvent> {
    const base = await this.d.llama.ensure(req.model)
    const inner = new OpenAIProvider({ id: this.id, baseUrl: `${base}/v1`, apiKey: '', headers: {} })
    this.d.llama.hold()
    try {
      yield* inner.stream({ ...req, model: 'local' })
    } finally {
      this.d.llama.release()
    }
  }
}
