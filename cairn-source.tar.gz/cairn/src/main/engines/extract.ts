import fs from 'node:fs'
import fsp from 'node:fs/promises'
import path from 'node:path'

export async function extractArchive(file: string, destDir: string): Promise<void> {
  await fsp.mkdir(destDir, { recursive: true })
  const lower = file.toLowerCase()
  if (lower.endsWith('.zip')) {
    const extract = (await import('extract-zip')).default
    await extract(file, { dir: path.resolve(destDir) })
  } else if (lower.endsWith('.tar.gz') || lower.endsWith('.tgz')) {
    const tar = await import('tar')
    await tar.x({ file, cwd: destDir })
  } else {
    throw new Error(`Unsupported archive type: ${path.basename(file)}`)
  }
}

/** Find the first file whose name (case-insensitive) is in `names`, searching breadth-first up to `maxDepth`. */
export async function findFile(root: string, names: string[], maxDepth = 4): Promise<string | null> {
  const wanted = names.map((n) => n.toLowerCase())
  let level = [root]
  for (let depth = 0; depth <= maxDepth && level.length; depth++) {
    const next: string[] = []
    for (const dir of level) {
      let entries: fs.Dirent[]
      try {
        entries = await fsp.readdir(dir, { withFileTypes: true })
      } catch {
        continue
      }
      // Preserve the caller's preference order of names.
      for (const want of wanted) {
        const hit = entries.find((e) => e.isFile() && e.name.toLowerCase() === want)
        if (hit) return path.join(dir, hit.name)
      }
      for (const e of entries) if (e.isDirectory()) next.push(path.join(dir, e.name))
    }
    level = next
  }
  return null
}
