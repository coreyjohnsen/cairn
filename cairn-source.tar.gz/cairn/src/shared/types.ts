// Shared domain types — imported by main, preload and renderer.
// Keep this file free of runtime dependencies.

/** Same values as OsPlatform, declared here so the renderer does not need Node typings. */
export type OsPlatform = 'aix' | 'android' | 'cygwin' | 'darwin' | 'freebsd' | 'haiku' | 'linux' | 'netbsd' | 'openbsd' | 'sunos' | 'win32'

/* ───────────────────────────── Appearance ───────────────────────────── */

export type ThemeId = 'system' | 'alpenglow' | 'glacier' | 'granite' | 'timberline'

export interface AppearanceSettings {
  theme: ThemeId
  fontScale: number // 0.85 – 1.25
  ridgelines: boolean // decorative mountain backdrops
  reduceMotion: boolean
}

/* ───────────────────────────── Providers / models ───────────────────────────── */

/** openai = any OpenAI-compatible server, anthropic = Anthropic Messages API, local = built-in llama.cpp */
export type ProviderKind = 'openai' | 'anthropic' | 'local'

export interface ModelCaps {
  vision?: boolean
  tools?: boolean
  reasoning?: boolean
}

export interface ProviderModel extends ModelCaps {
  id: string
  name?: string
  contextLength?: number
}

export interface ProviderConfig {
  id: string
  name: string
  kind: ProviderKind
  baseUrl: string
  apiKey: string
  enabled: boolean
  preset?: string
  /** Extra HTTP headers (e.g. OpenRouter attribution). */
  headers: Record<string, string>
  /** Models the user typed in by hand (for servers with no /models endpoint). */
  manualModels: ProviderModel[]
  /** Per-model capability overrides keyed by model id. */
  capOverrides: Record<string, ModelCaps>
}

export interface ModelOption {
  /** `${providerId}::${modelId}` */
  ref: string
  providerId: string
  providerName: string
  id: string
  name: string
  caps: ModelCaps
  contextLength?: number
}

export function makeModelRef(providerId: string, modelId: string): string {
  return `${providerId}::${modelId}`
}
export function parseModelRef(ref: string | undefined | null): { providerId: string; modelId: string } | null {
  if (!ref) return null
  const i = ref.indexOf('::')
  if (i < 0) return null
  return { providerId: ref.slice(0, i), modelId: ref.slice(i + 2) }
}

export interface DetectedServer {
  presetId: string
  name: string
  baseUrl: string
  modelCount: number
}

/* ───────────────────────────── Messages / conversations ───────────────────────────── */

export interface Attachment {
  id: string
  kind: 'image' | 'text'
  name: string
  mime: string
  /** File name inside <data>/attachments */
  file: string
  size: number
  /** For text attachments: the extracted text (also inlined into the prompt). */
  text?: string
}

export interface ToolCall {
  id: string
  name: string
  /** Raw JSON string exactly as produced by the model. */
  arguments: string
}

/** Light reference to a generated image so chat can render it without a lookup. */
export interface ImageRef {
  id: string
  file: string
  thumb: string
  prompt: string
  width: number
  height: number
}

export interface MessageUsage {
  promptTokens?: number
  completionTokens?: number
  tokensPerSecond?: number
}

export interface ChatMessage {
  id: string
  role: 'user' | 'assistant' | 'tool'
  createdAt: number
  content: string
  reasoning?: string
  attachments?: Attachment[]
  /** assistant: tool calls requested */
  toolCalls?: ToolCall[]
  /** tool: which call this answers */
  toolCallId?: string
  toolName?: string
  isError?: boolean
  /** tool call was refused by the user */
  denied?: boolean
  images?: ImageRef[]
  status?: 'streaming' | 'done' | 'aborted' | 'error'
  error?: string
  /** Model that produced an assistant message (display name). */
  model?: string
  durationMs?: number
  usage?: MessageUsage
  /** Informational line shown in the transcript (never sent to the model). */
  notice?: string
}

export interface ConversationParams {
  temperature?: number
  topP?: number
  maxTokens?: number
}

export interface ImageTarget {
  backendId: string
  model: string
}

export interface Conversation {
  id: string
  title: string
  createdAt: number
  updatedAt: number
  pinned?: boolean
  titleSet?: boolean
  modelRef?: string
  systemPrompt?: string
  workspace?: string
  toolsEnabled: boolean
  imageTarget?: ImageTarget
  params: ConversationParams
  messages: ChatMessage[]
}

export interface ConversationSummary {
  id: string
  title: string
  createdAt: number
  updatedAt: number
  pinned?: boolean
  messageCount: number
  preview: string
}

export type ConversationPatch = Partial<
  Pick<
    Conversation,
    'title' | 'modelRef' | 'systemPrompt' | 'workspace' | 'toolsEnabled' | 'imageTarget' | 'params' | 'pinned'
  >
>

export interface AttachmentInput {
  name: string
  mime: string
  data: Uint8Array
}

/* ───────────────────────────── Chat run events ───────────────────────────── */

export type ApprovalKind = 'write' | 'edit' | 'delete' | 'move' | 'command' | 'network' | 'generic'

export interface ApprovalRequest {
  id: string
  toolCallId: string
  toolName: string
  source: 'builtin' | 'custom' | 'mcp'
  kind: ApprovalKind
  title: string
  path?: string
  command?: string
  cwd?: string
  /** Unified diff-ish preview (edit/write). */
  diff?: string
  args: unknown
  /** Why approval is required (e.g. outside workspace). */
  reason?: string
}

export type ApprovalDecision = 'allow' | 'allow-chat' | 'always' | 'deny'

export type ChatEvent =
  | { type: 'run-start'; runId: string; conversationId: string }
  | { type: 'message'; runId: string; conversationId: string; message: ChatMessage }
  | { type: 'delta'; runId: string; conversationId: string; messageId: string; content?: string; reasoning?: string }
  | { type: 'tool-progress'; runId: string; conversationId: string; toolCallId: string; label?: string; progress?: number }
  | { type: 'approval'; runId: string; conversationId: string; approval: ApprovalRequest }
  | { type: 'approval-resolved'; runId: string; conversationId: string; approvalId: string }
  | { type: 'status'; runId: string; conversationId: string; status: string }
  | { type: 'title'; conversationId: string; title: string }
  | { type: 'run-end'; runId: string; conversationId: string; outcome: 'done' | 'aborted' | 'error'; error?: string }

export interface SendRequest {
  conversationId: string
  text: string
  attachments?: AttachmentInput[]
  /** 'image' sends the text straight to the image generator. */
  mode?: 'chat' | 'image'
}

/* ───────────────────────────── Tools ───────────────────────────── */

export type ToolPermission = 'auto' | 'ask' | 'deny'
export type ToolSource = 'builtin' | 'custom' | 'mcp'

export interface ToolInfo {
  name: string
  description: string
  source: ToolSource
  group: string
  permission: ToolPermission
  defaultPermission: ToolPermission
  available: boolean
  unavailableReason?: string
}

export type CustomToolImpl =
  | { type: 'command'; file: string; args: string[]; cwd?: string; timeoutSec: number }
  | { type: 'http'; method: 'GET' | 'POST' | 'PUT' | 'DELETE' | 'PATCH'; url: string; headers: Record<string, string>; body?: string; timeoutSec: number }
  | { type: 'javascript'; code: string; timeoutSec: number }

export interface CustomToolConfig {
  id: string
  name: string
  description: string
  enabled: boolean
  /** JSON Schema (type: object) as a string for easy editing. */
  parameters: string
  permission: ToolPermission
  impl: CustomToolImpl
}

export interface McpServerConfig {
  id: string
  name: string
  enabled: boolean
  transport: 'stdio' | 'http'
  command: string
  args: string[]
  env: Record<string, string>
  cwd?: string
  url: string
  headers: Record<string, string>
  permission: ToolPermission
}

export interface McpStatus {
  id: string
  state: 'connecting' | 'connected' | 'error' | 'disabled'
  error?: string
  tools: { name: string; description: string }[]
}

export interface ToolTestResult {
  ok: boolean
  output: string
  durationMs: number
}

/* ───────────────────────────── Images ───────────────────────────── */

export type ImageBackendKind = 'builtin' | 'comfyui' | 'a1111' | 'openai'

export interface ImageBackendConfig {
  id: string
  name: string
  kind: ImageBackendKind
  enabled: boolean
  baseUrl: string
  apiKey: string
  /** ComfyUI: custom API-format workflow with {{placeholders}}; empty = built-in default workflow. */
  comfyWorkflow: string
  defaultModel: string
}

export type SdArch = 'sd' | 'sdxl' | 'flux' | 'sd3' | 'custom'

export interface SdModelConfig {
  id: string
  name: string
  arch: SdArch
  /** Single-file checkpoint (passed as -m). */
  model: string
  /** Diffusion-only weights (Flux / SD3 GGUF etc.) passed as --diffusion-model. */
  diffusionModel: string
  vae: string
  clipL: string
  clipG: string
  t5xxl: string
  steps: number
  cfg: number
  sampler: string
  width: number
  height: number
  vaeTiling: boolean
  offloadToCpu: boolean
  clipOnCpu: boolean
  flashAttn: boolean
  extraArgs: string
}

export interface ImageSettings {
  backends: ImageBackendConfig[]
  localModels: SdModelConfig[]
  defaultTarget?: ImageTarget
  /** Stop the built-in LLM while the built-in image engine runs, to free VRAM. */
  unloadLlmForImages: boolean
  negativePrompt: string
}

export interface ImageGenRequest {
  prompt: string
  negativePrompt?: string
  target?: ImageTarget
  width: number
  height: number
  steps?: number
  cfgScale?: number
  /** -1 = random */
  seed: number
  sampler?: string
  count: number
  initImageId?: string
  strength?: number
  source: 'hub' | 'chat'
  conversationId?: string
}

export interface ImageRecord {
  id: string
  file: string
  thumb: string
  createdAt: number
  prompt: string
  negativePrompt: string
  backendId: string
  backendName: string
  model: string
  width: number
  height: number
  steps?: number
  cfgScale?: number
  seed: number
  sampler?: string
  durationMs: number
  source: 'hub' | 'chat'
  conversationId?: string
  favorite: boolean
  initImageId?: string
}

export interface ImageJob {
  id: string
  status: 'queued' | 'running' | 'done' | 'error' | 'cancelled'
  request: ImageGenRequest
  /** 0..1 */
  progress: number
  label?: string
  error?: string
  resultIds: string[]
  createdAt: number
}

export interface ImageTargetOption {
  backendId: string
  backendName: string
  kind: ImageBackendKind
  model: string
  label: string
  supportsImg2Img: boolean
  supportsNegative: boolean
  defaults?: { width: number; height: number; steps: number; cfg: number; sampler: string }
  available: boolean
  unavailableReason?: string
}

/* ───────────────────────────── Engines / GPU ───────────────────────────── */

export type GpuVendor = 'nvidia' | 'amd' | 'intel' | 'apple' | 'unknown'
export type EngineBackend = 'cuda' | 'rocm' | 'vulkan' | 'cpu'
export type EngineId = 'llama' | 'sd'

export interface GpuDevice {
  vendor: GpuVendor
  name: string
  vramMB?: number
  driver?: string
  /** NVIDIA: highest CUDA version the driver supports, e.g. "12.4" */
  cudaVersion?: string
  /** NVIDIA compute capability, e.g. "8.6" */
  computeCap?: string
}

export interface GpuInfo {
  platform: OsPlatform
  arch: string
  devices: GpuDevice[]
  /** ROCm / HIP runtime appears to be installed. */
  rocmRuntime: boolean
  vulkanRuntime: boolean
  recommended: EngineBackend
  /** Human-readable reasoning shown in the UI. */
  notes: string[]
  cpuThreads: number
  totalRamMB: number
}

export interface InstalledBuild {
  id: string
  engine: EngineId
  tag: string
  backend: EngineBackend
  dir: string
  binary: string
  assetName: string
  installedAt: number
}

export interface EngineStatus {
  engine: EngineId
  builds: InstalledBuild[]
  activeBuildId?: string
  /** Absolute binary currently resolved (custom path or managed build), if any. */
  resolvedBinary?: string
  recommended: EngineBackend
  available: EngineBackend[]
}

export interface EngineInstallProgress {
  engine: EngineId
  phase: 'resolving' | 'downloading' | 'extracting' | 'done' | 'error'
  label: string
  received?: number
  total?: number
  error?: string
}

export interface EngineSettings {
  customPath: string
  backendPref: 'auto' | EngineBackend
  activeBuildId: string
  env: Record<string, string>
}

export interface LocalRuntimeSettings {
  contextSize: number
  /** -1 = all layers (auto) */
  gpuLayers: number
  threads: number
  port: number
  flashAttn: 'auto' | 'on' | 'off'
  extraArgs: string
  /** Stop the server after this many idle minutes (0 = never). */
  idleUnloadMinutes: number
  /** Last model loaded, restored on demand. */
  lastModelPath: string
}

export type LlamaState = 'stopped' | 'starting' | 'running' | 'error'

export interface LlamaStatus {
  state: LlamaState
  modelPath?: string
  mmprojPath?: string
  port?: number
  pid?: number
  error?: string
  startedAt?: number
  /** Last lines of server output. */
  log: string[]
}

export interface LocalModelFile {
  path: string
  name: string
  sizeBytes: number
  quant?: string
  mmprojPath?: string
  /** Where it was found (library root). */
  root: string
}

export interface ImageWeightFile {
  path: string
  name: string
  sizeBytes: number
  root: string
}

/* ───────────────────────────── Downloads / hubs ───────────────────────────── */

export interface DownloadSpec {
  url: string
  /** Sub-directory under the models dir: 'llm' | 'image' | 'vae' | 'text-encoders' */
  subdir: string
  filename: string
  source: 'hf' | 'civitai' | 'url'
  label?: string
}

export interface DownloadItem {
  id: string
  spec: DownloadSpec
  dest: string
  status: 'queued' | 'downloading' | 'done' | 'error' | 'cancelled'
  received: number
  total: number
  error?: string
  speedBps?: number
}

export interface HfModelHit {
  id: string
  downloads: number
  likes: number
  tags: string[]
  updated?: string
}
export interface HfFile {
  path: string
  size: number
  /** Direct download URL (respects the configured Hugging Face endpoint/mirror). */
  url: string
}
export interface CivitaiHit {
  id: number
  name: string
  type: string
  creator?: string
  downloads?: number
  versions: {
    id: number
    name: string
    baseModel?: string
    files: { id: number; name: string; sizeKB: number; downloadUrl: string; format?: string; primary?: boolean }[]
  }[]
}

/* ───────────────────────────── Settings ───────────────────────────── */

export interface ChatSettings {
  systemPrompt: string
  temperature: number
  topP: number
  /** 0 = provider default */
  maxTokens: number
  autoTitle: boolean
  maxAgentSteps: number
  toolOutputLimit: number
  toolsDefault: boolean
  detectImageIntent: boolean
  sendOnEnter: boolean
  /** Soft context budget (tokens) used to trim long chats; 0 = auto for local, unlimited otherwise. */
  contextBudget: number
}

export interface AgentSettings {
  workspace: string
  allowOutsideWorkspace: boolean
  autoApproveAll: boolean
  toolPermissions: Record<string, ToolPermission>
  shell: 'auto' | 'powershell' | 'cmd' | 'bash' | 'sh'
  shellTimeoutSec: number
  searxngUrl: string
}

export interface PathSettings {
  modelsDir: string
  extraModelDirs: string[]
  hfEndpoint: string
  hfToken: string
  civitaiToken: string
}

export interface Settings {
  version: number
  appearance: AppearanceSettings
  providers: ProviderConfig[]
  defaultModel: string
  chat: ChatSettings
  agent: AgentSettings
  customTools: CustomToolConfig[]
  mcpServers: McpServerConfig[]
  engines: { llama: EngineSettings; sd: EngineSettings }
  local: LocalRuntimeSettings
  image: ImageSettings
  paths: PathSettings
  onboardingDismissed: boolean
}

/* ───────────────────────────── System ───────────────────────────── */

export interface SystemInfo {
  platform: OsPlatform
  arch: string
  appVersion: string
  dataDir: string
  modelsDir: string
  home: string
  isPackaged: boolean
}
